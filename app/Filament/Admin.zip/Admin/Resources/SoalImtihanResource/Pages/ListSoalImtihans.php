<?php

namespace App\Filament\Admin\Resources\SoalImtihanResource\Pages;

use App\Filament\Admin\Resources\SoalImtihanResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListSoalImtihans extends ListRecords
{
    protected static string $resource = SoalImtihanResource::class;

    protected function getHeaderActions(): array
    {
        return [
            // Actions\CreateAction::make(),
        ];
    }
}
