<?php

namespace App\Filament\Admin\Resources\AdminKelasSantriResource\Pages;

use App\Filament\Admin\Resources\AdminKelasSantriResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAdminKelasSantri extends CreateRecord
{
    protected static string $resource = AdminKelasSantriResource::class;
}
