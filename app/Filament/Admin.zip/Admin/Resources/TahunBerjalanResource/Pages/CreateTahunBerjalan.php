<?php

namespace App\Filament\Admin\Resources\TahunBerjalanResource\Pages;

use App\Filament\Admin\Resources\TahunBerjalanResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateTahunBerjalan extends CreateRecord
{
    protected static string $resource = TahunBerjalanResource::class;
}
