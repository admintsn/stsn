<?php

namespace App\Filament\Admin\Resources\AdminDataSantriResource\Pages;

use App\Filament\Admin\Resources\AdminDataSantriResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAdminDataSantri extends CreateRecord
{
    protected static string $resource = AdminDataSantriResource::class;
}
