<?php

namespace App\Filament\Admin\Resources\TsnuniqueResource\Pages;

use App\Filament\Admin\Resources\TsnuniqueResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateTsnunique extends CreateRecord
{
    protected static string $resource = TsnuniqueResource::class;
}
