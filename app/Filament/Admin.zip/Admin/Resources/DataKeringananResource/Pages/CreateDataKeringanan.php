<?php

namespace App\Filament\Admin\Resources\DataKeringananResource\Pages;

use App\Filament\Admin\Resources\DataKeringananResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDataKeringanan extends CreateRecord
{
    protected static string $resource = DataKeringananResource::class;
}
