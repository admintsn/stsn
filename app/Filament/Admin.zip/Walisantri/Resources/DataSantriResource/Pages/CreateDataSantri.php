<?php

namespace App\Filament\Walisantri\Resources\DataSantriResource\Pages;

use App\Filament\Walisantri\Resources\DataSantriResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDataSantri extends CreateRecord
{
    protected static string $resource = DataSantriResource::class;
}
