<?php

namespace App\Filament\Walisantri\Resources\DataNilaiResource\Pages;

use App\Filament\Walisantri\Resources\DataNilaiResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDataNilai extends CreateRecord
{
    protected static string $resource = DataNilaiResource::class;
}
