<?php

namespace App\Filament\Tsn\Resources\PSB\PendaftarSantriBaruResource\Pages;

use App\Filament\Tsn\Resources\PSB\PendaftarSantriBaruResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePendaftarSantriBaru extends CreateRecord
{
    protected static string $resource = PendaftarSantriBaruResource::class;
}
