<?php

namespace App\Filament\Tsn\Resources\PSB\PendaftarNaikQismResource\Pages;

use App\Filament\Tsn\Resources\PSB\PendaftarNaikQismResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePendaftarNaikQism extends CreateRecord
{
    protected static string $resource = PendaftarNaikQismResource::class;
}
