<?php

namespace App\Filament\Tsn\Resources\PSB\DataKedatanganResource\Pages;

use App\Filament\Tsn\Resources\PSB\DataKedatanganResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDataKedatangan extends CreateRecord
{
    protected static string $resource = DataKedatanganResource::class;
}
