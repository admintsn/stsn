<?php

namespace App\Filament\Tsn\Resources\PSB\UpdateSiapNaikQismResource\Pages;

use App\Filament\Tsn\Resources\PSB\UpdateSiapNaikQismResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateUpdateSiapNaikQism extends CreateRecord
{
    protected static string $resource = UpdateSiapNaikQismResource::class;
}
