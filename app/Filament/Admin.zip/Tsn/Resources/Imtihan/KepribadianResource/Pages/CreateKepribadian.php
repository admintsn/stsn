<?php

namespace App\Filament\Tsn\Resources\Imtihan\KepribadianResource\Pages;

use App\Filament\Tsn\Resources\Imtihan\KepribadianResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateKepribadian extends CreateRecord
{
    protected static string $resource = KepribadianResource::class;
}
