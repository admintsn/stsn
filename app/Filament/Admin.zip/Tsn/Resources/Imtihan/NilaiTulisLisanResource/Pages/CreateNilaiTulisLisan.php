<?php

namespace App\Filament\Tsn\Resources\Imtihan\NilaiTulisLisanResource\Pages;

use App\Filament\Tsn\Resources\Imtihan\NilaiTulisLisanResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateNilaiTulisLisan extends CreateRecord
{
    protected static string $resource = NilaiTulisLisanResource::class;
}
