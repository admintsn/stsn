<?php

namespace App\Filament\Tsn\Resources\Imtihan\NilaiHafalanResource\Pages;

use App\Filament\Tsn\Resources\Imtihan\NilaiHafalanResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateNilaiHafalan extends CreateRecord
{
    protected static string $resource = NilaiHafalanResource::class;
}
